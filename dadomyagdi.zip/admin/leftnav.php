<ul class="menu">
	<li>
  		<p>Admin Site</p>
  		<ul>
    		<li><a href="index.php">Home</a></li>
      		<li><a href="changepswd.php">Change Password</a></li>
      		<li><a href="logout.php">Logout</a></li>
    	</ul>
  	</li>
  	<li>
  		<p>Manage Info</p>
    	<ul>
            <li><a href="cms.php">Manage Contents</a></li>
            <li><a href="cms.php?groupType=Header">Menubar</a></li>
            <li><a href="cms.php?id=8&parentId=0&groupType=Other">Slider</a></li>
            <li><a href="cms.php?groupType=Information%20Categories">Information Categories</a></li>

            <li><a href="cms.php?id=176&parentId=0&groupType=Other">Welcome to DADO, Myagdi</a></li>
            <li><a href="cms.php?id=274&parentId=0&groupType=Other">Message From Program Chief</a></li>
            <li><a href="cms.php?id=388&parentId=0&groupType=Other">Message from Information Officer</a></li>
            <li><a href="cms.php?id=431&parentId=0&groupType=Other">Our Videos</a></li>
            
            <!--<li><a href="feedbacks.php">View Feedbacks</a></li>
            <li><a href="enewsletters.php">View Suscribes</a></li>-->
            
            <li><a href="cms.php?groupType=Other">Manage Other</a></li>
            <li><a href="bills.php">Manage Bills</a></li>
            <li><a href="subscription.php">Manage SMS Subscription</a></li>
    	</ul>
  	</li>
  	
</ul>